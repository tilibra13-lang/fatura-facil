plugins {
    id("com.android.application")
}

android {
    namespace = "com.faturafacil.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.faturafacil.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

