# Fatura Fácil - Projeto Android

Este projeto abre o Fatura Fácil como aplicativo Android usando WebView.

## Como gerar o APK

1. Instale o Android Studio.
2. Abra o Android Studio.
3. Clique em **Open**.
4. Selecione a pasta `FaturaFacil_Android_Project`.
5. Aguarde o Gradle sincronizar.
6. Vá em **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Quando terminar, clique em **locate** para encontrar o arquivo APK.
8. Envie o APK para o celular e instale.

## Observação

Os dados do Fatura Fácil ficam salvos no armazenamento local do app no celular.
